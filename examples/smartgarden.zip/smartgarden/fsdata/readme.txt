This directory contains a script ('makefsdata') to create C code suitable for
httpd for given html pages (or other files) in a directory.
